<?php

$message = 'Payment error!';

echo $message;

?>