﻿<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

$paymentnepal_skey = $params->get('paymentnepal_skey', '');
$paymentnepal_key = $params->get('paymentnepal_key', '');
$paymentnepal_order_id = $params->get('paymentnepal_order_id', 0);
$paymentnepal_cost = $params->get('paymentnepal_cost', '');
$paymentnepal_name = $params->get('paymentnepal_name', 'Payment name');
$paymentnepal_comment = $params->get('paymentnepal_comment', 'Comment');

$user =& JFactory::getUser();
$email = $user->get('email');

$paymentnepal_email = !empty($email) ? $email : '';

JHTML::_('behavior.formvalidation');

?>

<table width="99%" align="center" cellpadding="0" cellspacing="0" border="0">
<tr>
  <td width="100%" align="center">
	<form method="POST" id="form-paymentnepal" class="form-validate" accept-charset="UTF-8" action="https://pay.paymentnepal.com/alba/input">
	  <input type="hidden" name="key" value="<?php echo $paymentnepal_key ?>" />
	  <b>Order id:</b><br />
	  <input class="required validate-numeric" type="text" name="order_id" value="<?php echo $paymentnepal_order_id ?>" /><br /><br />
	  <b>Amount:</b><br />
	  <input class="required validate-numeric" type="text" name="cost" value="<?php echo $paymentnepal_cost ?>" /><br /><br />
	  <b>Payment name:</b><br />
	  <input type="text" name="name" value="<?php echo $paymentnepal_name ?>" /><br /><br />
	  <b>E-mail:</b><br />
	  <input class="required validate-email" type="text" name="default_email" value="<?php echo $paymentnepal_email ?>" /><br /><br />
	  <b>Comment:</b><br />
	  <input type="text" name="comment" value="<?php echo $paymentnepal_comment ?>" /><br /><br />
	  <input class="button validate" type="submit" value="Pay" />
	</form>
  </td>
</tr>
</table>
