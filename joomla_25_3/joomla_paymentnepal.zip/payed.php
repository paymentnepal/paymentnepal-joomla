<?php

require_once ('parse.inc.php');

defined('_JEXEC') or die('Direct Access to this location is not allowed.');

$q = $_GET;

$params = _yusoft_parse($q);

if ($params['check']) {

  $sum = $params['partner_income'];

  $message = 'Some text';

}
else {

  $message  = 'Sign check failed';

}

echo $message;

?>