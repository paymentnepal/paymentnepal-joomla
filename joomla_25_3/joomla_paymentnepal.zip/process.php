<?php

require_once ('parse.inc.php');

$q = $_POST;

$params = _yusoft_parse($q);

if ($params['check']) {


  $message  = 'Some text';

}
else {


  $message  = 'Sign check failed';


}

jimport('joomla.error.log');
$log =& JLog::getInstance();
$log->addEntry(array('comment' => $message, 'status' => 0));

?>