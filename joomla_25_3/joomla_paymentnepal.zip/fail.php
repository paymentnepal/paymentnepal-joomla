<?php


$message = 'Payment failed';

echo $message;

?>